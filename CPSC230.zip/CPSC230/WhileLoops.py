# While Loops

# Check what time it is. If it is after 7 AM, your alarm should go off. 
# If it is before 7 AM, keep sleeping.

time = input('Please enter time: ')
t = int(time)

if t > 7:
    print('Beep!')

else:
    print('Keep sleeping.')

# while loop basic syntax
# print the value of x while x < 3
x = 0

while x < 3:
    print(x) # do stuff
    x += 1

print('All Done!')

# while loop is NEVER True

y = 4
while y > 10:
    print(y)
    y -= 1

print('Bye!')

# while loop is ALWAYS True

# z = 5
# while z < 10:
# print('z is', z)
# infinite loop

# sentinel loop - password example
''' 
Help a user set a new password. 
Their password must follow these rules:
    - be longer than 10 letters
    - less than 20 letters
    - must start with the letter C.
    
Hint: the .startswith() method returns True if a
string starts with the given letter.
Ex:
"Hello".startswith("H") will return True
"Hello".startswith("Z") will return False
'''
bad_password = True
while bad_password: # while they have a bad password, get a new one and check it
    password = input('Please enter password: ')
    p = str(password)

    if (10 < len(p) < 20) and p.startswith('C'):
        # I have found a good password
        bad_password = False

print('Good password: ', p)


# want loop to run while they have a bad password





# break - number guessing game
'''
Write a game that asks a user to guess a number.
If the user guesses it correctly, end the game
'''
# correct_num = 5
# c = int(correct_num)

# while True: # until I break out of my loop elsewhere, keep runnning
    # get a guess from the user
    # if that guess is correct, break out of the loop
    # guess = int(input('Please enter a number: '))
    # if guess == c:
        # break
    # print('Wrong!')

# print('Congrats! You guessed it!')

# continue - sum of all odd numbers 0 to 5

x = 0
sum = 0

# simple while loop (print)
# while x < 6:
    # print(x)
    # x += 1

# add all numbers 0 to 5
# while x < 6:
    # sum = sum + x
    # x += 1
# print(sum)

# add all ODD numbers 0 to 5

x = 0
sum = 0
while x < 6:
    if x % 2 == 0:
        x += 1  # I have found an even number
        continue
    sum = sum + x
    x += 1
print(sum)


 