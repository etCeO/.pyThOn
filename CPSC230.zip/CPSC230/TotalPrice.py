
# Ethan E. Lopez
# 002425516
# etlopez@chapman.edu
# CPSC 230 - Section 2
# Program Assignment 1

purchase_price = input('Please enter purchase price: ')
p = float(purchase_price)
sales_tax_rate = input('Please enter sales tax rate: ')
s = float(sales_tax_rate)

if p >= 0:
    sales_tax = p * (s / 100)
    t = float(sales_tax)
    Total_Price = round(p + t, 2)
    print(f'The total price is ${Total_Price}.')

else:
    print('Invalid number')
