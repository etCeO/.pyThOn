'''
Your name: Ethan E. Lopez
Teammate(s) name(s): George, William
'''

'''
1. Write some code that checks to see if a user-entered string starts with an uppercase letter. Print out "Upper"
if it starts with upper and "Lower" if it does not. Then, write a function called upper_checker() that does the same
thing, but returns "Upper" or "Lower" instead of printing. Read over our FUNction Facts sheet to make sure you're 
following our function guidelines. Don't forget to call your function.
'''

def upper_checker(s):
    if s[0].isupper():
        return 'Upper'
    elif s[0].islower():
        return 'Lower'
    
print(upper_checker('I love you'))
print(upper_checker('i dunno'))
print(upper_checker('!'))

'''
2. Write a function dice_roller() which takes in no arguments, and uses the random.randint() function 
to "roll" a die, returning the value. "Roll" your die twice and print out the value returned.
'''
import random

def dice_roller():
    r = random.randint(1, 6)
    return r

print(dice_roller())
print(dice_roller())

'''
3. Write a function, dice_roller2() function to take in an argument, sides, which says the number of sides 
the die has. Set the default to six. Roll a d6 and a d20.
'''
def dice_roller2(sides = 6):
    r = random.randint(1, sides)
    return r

print(dice_roller2())
print(dice_roller2(20))

'''
4. Write a function, euclidean() that takes in 4 arguments, x1, x2, y1, and y2, and calculates (+ returns) 
the euclidean distance between the points (x1,y1) and (x2,y2). Make the default arguments 1 for all 4 arguments.
'''

def euclidean(x1 = 1, x2 = 1, y1 = 1, y2 = 1):
    d = (((x2 - x1) ** 2) + ((y2 - y1) ** 2)) ** 0.5
    return d

print(euclidean())
print(euclidean(1, 2, 3, 4))

'''
5. Write a function called factorial() that takes in an integer, n, and returns the factorial of that number. 
Make the default value 9.
'''

def factorial(n = 9):
    f = 1
    for i in range(1, n+1):
        f *= i
    return f

print(factorial())
print(factorial(3))

'''
6. Write a function adder_subtracter() that takes in a STRING, equation, which looks
like '5 + 2' or '10 - 4' or '16 - 30' and performs the operation intended by
the user, returning the result. Make the default string '1 + 1'.
You can assume the structure will ALWAYS be: some number, a space, either + or -, a space, 
and then another number. However, the numbers might be big, like 19834.
'''
def adder_subtracter(string = '1 + 1'):
    s = string.split()
    if s[1] == '+':
        r = int(s[0]) + int(s[2])
        return r
    elif s[1] == '-':
        r = int(s[0]) - int(s[2])
        return r
    
print(adder_subtracter())
print(adder_subtracter('5 - 6'))
print(adder_subtracter('54 + 7'))

