'''
Your name: Ethan E. Lopez
Teammate(s) name(s): William, Ethan B. , George
'''

'''
1. Set i equal to 3. Write a while loop that prints out the value of i while i is less than 10.
Increment i by 1 each time.
'''
i=3
while i<10:
    print(i)
    i+=1
'''
2. Write a while loop that continuously asks the user to enter an integer.
Print out "incorrect" each time they enter a number that isn't 8.
Print out "you guessed it!" when they guess 8
'''

'''
3. Write a while loop that prints out "Duck" until the user enters the word "Goose"
'''


'''
4. Write a while loop that runs until the user enters a number greater than 50
'''
