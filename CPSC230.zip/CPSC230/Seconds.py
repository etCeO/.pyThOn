
# Ethan E. Lopez
# 002425516
# etlopez@chapman.edu
# CPSC 230 - Section 2
# Program Assignment 1

second = input('Please enter # of seconds: ')
s = int(second)

if s >= 0:
    hours = (s // 60) // 60
    h = int(hours)
    minutes = (s // 60) % 60
    m = int(minutes)
    seconds = (((s % 60) % 60)) % 60
    s1 = int(seconds)

    print(s, 'seconds is ', h, 'hours, ', m, 'minutes, and ', s1, 'seconds.')

else:
    print('Invalid number')
