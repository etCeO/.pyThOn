'''
A. Write a function that accepts a string and prints the number 
of upper and lower case letters in that string. If the string is longer 
than 30 characters, or less than 5 characters, print "Rejected" instead of the counts 
'''

def string_evaluator(string):
    uppercase_count = 0
    lowercase_count = 0
    if len(string) > 30 or len(string) < 5:
        print('Rejected')
    else:
        for i in string:
            if i.isupper():
                uppercase_count += 1
            elif i.islower():
                lowercase_count += 1
        print(uppercase_count, 'uppercase letters')
        print(lowercase_count, 'lowercase letters')

string = input('Please enter a string: ')

string_evaluator(string)

'''
B. Write a function that takes a list and returns a new list with only
the distinct elements from the first list. Do not make use of sets.
Ex: [1,1,2,3,2,4,5,6,6,7] as an input should return [1,2,3,4,5,6,7]
'''

def distinct_list(list_of_numbers):
    list_of_numbers.sort()
    new_list = []
    for i in list_of_numbers:
        if i not in new_list:
            new_list.append(i)

    return new_list

list_of_numbers = [1,1,2,3,2,4,5,6,6,7]

print(distinct_list(list_of_numbers))

'''
C. Write a function to check whether a string is a pangram or not. It should
return True if it is a pangram and False otherwise.
'''

def pangram_check(string1):
    string1 = string1.lower()
    if 'abcdefghijklmnopqrstuvwxyz' in string1:
        return True
    else:
        return False
    
string1 = input('Please enter another string: ')
    
print(pangram_check(string1))

'''
D. Write a function that returns the largest number in a list. Do not utilize the max()
function.
'''

def largest_list_number(number_list):
    max_number = 0
    for i in number_list:
        if i > max_number:
            max_number = i

    return i

number_list = [3, 6, 3, 678, 8, 10, 1000]

print(largest_list_number(number_list))

'''
E. Write a function that accepts an integer and returns the largest factor of that number.
For example, the input 12 should return 6 and the input 24 should return 12
'''

def largest_factor(integer):
    j = 0
    for i in range(1, integer):
        if integer % i == 0:
            j = i
    return j

integer = int(input('Please enter an integer: '))

print(largest_factor(integer))

'''
F. Write a function that takes 2 lists and returns a list that only contains the
values that appear in both lists.
'''

def two_list_comparison(list_1, list_2):
    list_3 = []
    for i in list_1:
        if i in list_2:
            if i not in list_3:
                list_3.append(i)
            else:
                continue

    return list_3

list_1 = [4, 5, 7, 2, 3, 4, 7]
list_2 = [3, 4, 9, 10, 11, 5]

print(two_list_comparison(list_1, list_2))

