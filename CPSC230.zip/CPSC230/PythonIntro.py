
x=15 

while x<20: 
    print("God is great!")
    x+=1












