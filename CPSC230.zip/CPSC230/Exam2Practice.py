
# 1
# write out a function that generates 4 random numbers and returns them all
# print out the random numbers separately after you call the function

import random

def random_generator():
    a = random.randint(1, 100)
    b = random.randint(1, 100)
    c = random.randint(1, 100)
    d = random.randint(1, 100)
    return a, b, c, d

a, b, c, d = random_generator()

print(a)
print(b)
print(c)
print(d)

# 2
# two consecutive odd numbers that are prime are "twin primes"
# write a program that prints all twin primes 1 to 1000

prime_numbers = []

def prime(a, b):
    for i in range(a, b+1):
        if i == 2:
            prime_numbers.append(i)
        for j in range(2, i):
            if i % j == 0:
                break
            elif i - j == 1:
                prime_numbers.append(i)

    return prime_numbers

# a function that returns true if prime returns false otherwise

def is_prime(num):
    if num == 1:
        return False
    elif num == 2:
        return True
    for i in range(2, num):
        if num % i == 0:
            return False
        
    return True

def is_consecutive_odd(num1, num2):
    if num2 - num1 == 2:
        return True
    else:
        return False


num = int(input('Please enter number: '))

p = -1
for num in range(1, 1001):
    if is_prime(num) == True:
        if is_consecutive_odd(p, num) == True:
            print(p, num)
        p = num


# def twin_primes(prime_numbers):
    # twin_primes_list = []
    # for i in range(len(prime_numbers)):
        # if prime_numbers[i + 1] - prime_numbers[i] == 2:
            # twin_primes_list.append(i)
        # else:
            # continue
    
    # return twin_primes_list



a = int(input('Please enter first number: '))
b = int(input('Please enter second number: '))

print(prime(a, b))
# print(twin_primes(prime_numbers))

# 3
# write a function that takes a double digit integer as an argument
# returns the product of the digits of that argument

def double_digit_product(number):
    number = str(number)
    p = int(number[0]) * int(number[1])
    return p

print(double_digit_product(27))
print(double_digit_product(43))

# 4
# what is the output of the following code?

# the first print statement calls the function func1(my_list)
    # func1 creates b_list and appends 2, 4, and 6 to get b_list = [2, 4, 6]
    # then, my_list.pop removes 0 from my_list to get [2, -1]
    # the function then returns b_list
# so the output of print(func1(my_list)) is [2, 4, 6]

# in the second print statement, they ask to print the result, which calls func2(my_list)
    # going through func2(my_list), c_list is defined as my_list[0:2], which is [2, -1]
    # c_list.remove(2) removes 2 to get [-1]
    # then, c_list.append(7) adds 7 to my_list to get [-1, 7]
    # c_list.sort() sorts the function to get [-1, 7]
    # the function returns c_list 
# so the output of print(result) is [-1, 7]

# the third print statement, print(result.pop()) defaultly removes -1 (first number) from the print statement
# the output is then 7

def func1(my_list):
    b_list = []
    b_list.append(2)
    b_list.append(4)
    b_list.append(6)
    my_list.pop()
    return b_list

def func2(my_list):
    c_list = my_list[0:2]
    c_list.remove(2)
    c_list.append(7)
    c_list.sort()
    return c_list

my_list = [2, -1, 0]
result = func2(my_list)
print(func1(my_list))
print(result)
print(result.pop())


