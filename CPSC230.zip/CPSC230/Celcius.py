
# Ethan E. Lopez
# 002425516
# etlopez@chapman.edu
# CPSC 230 - Section 2
# Program Assignment 1

degrees_celcius = input('Please enter degrees Celcius: ')
c = float(degrees_celcius)

degrees_farenheit = (c * 9) / 5 + 32
f = float(degrees_farenheit)

print(c, 'degrees celcius is', f, 'degrees farenheit.')
