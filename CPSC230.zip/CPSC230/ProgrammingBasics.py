# Programming Basics



# output

print('Hello')

# input

info = input('Please enter some info: ')
print(info)

# errors
# Syntax Error

# print('Here is my message'

# Runtime Error

# print('Hello' * 'abc')

# Logic Error

print(3*2)
# print(3**2)
