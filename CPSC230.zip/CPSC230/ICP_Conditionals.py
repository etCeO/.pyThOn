'''
Your name: Ethan E. Lopez
Teammate(s) name(s): Lloyd, Ethan B,  George
'''


'''
1. Ask the user for an integer. Use an if statement to print "Even!" if the number is even
'''
'''
2. Ask the user to enter a word. 
Use an if/else statement to print "Cool!" if the word is "cat".
Print ":(" if the word is not cat.
'''
'''
3. The len() function returns the length of a String.
Use this function and a conditional to print "Big word!" if the word length is greater than 10
Print "Small word" otherwise.

'''


4. # Ask the user to input a number (it can be a decimal number)
# Divide this number by 4
# If the result is > 2.0, print "Big"
# Otherwise, print "Small"



5. # Help me figure out where to go on campus! On MWF I tech in Keck.
# On TTh I have class in Hashinger. On the weekend I am at home.
# Write code that asks the user to input the day of the week and 
# use ifs/elifs/elses to print out where I should
# be based on what day it is (Keck, Hashinger, or Home).


6. # Pretend you're writing some code for a convience store. Ask the user to
# input the name of an item (such as milk, lipgloss, sunscreen, etc).
# Check if the item is either "cigarettes" or "alcohol". If it is, ask the user
# how old they are and make sure they're old enough to buy the item (18 for
# cigarettes and 21 for alcohol). If they're not old enough, print "Sorry I can't
# sell you that.", If they are old enough, OR they're buying something else, print
# "Thank you for your purchase".

a=input("Put the name of an item: ")
if a== "cigarettes" or a == 'Cigarettes':
    print("oh")
    a=int(input("How old are you?: "))
    if a>=18:
        print("Thank you for your purchase")
    elif a<=18: 
        print("Sorry, I can't sell you that")
    else:
        print("What was your age again?")
elif a== "alcohol" or a == 'Alcohol':
    print("oh")
    a=int(input("How old are you?: "))
    if a>=21:
        print("Thank you for your purchase") 

    elif a<=21:
        print("Sorry, I can't sell you that")
    else: 
        print("What was your age again? ")
else: 
    print("Thank you for your purchase!")





'''

'''
7. # Ask the user to input 3 integers which represent the lengths of the sides of
# a triangle. Write some code to check if the triangle is equilateral (all sides
# the same length), isosceles (two sides are equal), or neither (no sides are equal).
# Print out the result for the user to see.
'''




'''



'''
9. Help your user choose what to make for dinner.
Ask them if they eat meat. If they do, ask if they want chicken or beef.
If they want chicken, ask if they want bbq sauce or buffalo sauce.
If they don't eat meat, ask them if they want pasta or soup.
If they want pasta, ask them if they want red sauce, pesto, or alfredo sauce.
Print out the dinner choice for all users.
'''
