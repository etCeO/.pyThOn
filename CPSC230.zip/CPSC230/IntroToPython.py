# Intro to Programming & Python

# import statements
import math
# import numpy


# statement
y = 100

# expression
print(10*7)

# comments
# this is a one line comment
# one line comment

'''
This is a
multiline comment
'''

'''
multi
line
comment
'''


# whitespace
2*3
2 * 3
# some whitespace is ignorable

2**8
2   **  3
# some is not

# 2* *3 # not okay

# indentation

if 2 == 3:
    print(':)')
else:
    print(':(')

# variables

num = 1
Num = 2
_num = 3

print(num)
print(Num)

num = 2
print(num) # 2

# bad variables
# 1num - starts with number
# for - is a keyword
num1 = 2

# only the variable should be on the left side of your equation
x = 4
# x + 1 = 4 #bad
x = 1 + 4 #good - expressions belong on the right side

# print(x=2) #no
x=2
print(x)
# variable_name = value

# snake_case/camelCase

mylongvariablename = 4
my_long_variable_name = 4 # snake case
myLongVariableName = 4 # camel case
