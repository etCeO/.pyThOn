'''
Your name: Ethan E. Lopez
Teammates name(s): George Guo, William, Ethan B.
'''

'''
1. When we are dealing with immutable types, we know that what happens in functions, 
stays in functions. I've written some code below to practice with. 
Before you run the code, write an explanation of what output you expect. 
Then run the code. Does your expected output match your actual output? 
If not, spend some time figuring out why and explain.
'''

def mystery_function(my_str):
    print(my_str)
    my_str = "Good night!"
    print(my_str)
    return my_str

my_str = "Good morning everyone!"
print(my_str[10])
mystery_function(my_str)
print(my_str)

# the first print statement prints out 'n' in index 10 of my_str
# the second statement calls the function mystery_function to print my_str 'Good morning everyone!'
    #  it then creates a new string called my_str in the local name space and assigns that value to 'Good night!'
    #  'Good night!' is printed
# for the last print statement, my_str refers to the main name space not defined in the function because it is immutable, so this prints 'Good morning everyone!'

# the expected output matches the explanation above :)


'''
2. When we are dealing with mutable types, we know that changing values in a function
will permanently change those values. 
I've written some code below to practice with. 
Before you run the code, write down the output you are expecting. 
Then run the code. Does your expected output match your actual output? 
If not, spend some time figuring out why.
'''

def mystery_function2(my_list):
    print(my_list)
    my_list.append("Hello")
    print(my_list)
    return my_list

my_list = ["A", "B", "C"]
print(my_list[2])
mystery_function2(my_list)
print(my_list)

# the first print statement prints 'C' in list of my_list at index 2
# the second statement calls the function mystery_function2 to print my_list ['A', 'B', 'C']
    # then it updates my_list with .append to add 'Hello' at the end of the list
    # my_list is printed again to now get ['A', 'B', 'C', 'Hello']
# for the last print statement, this is referring to the function since lists are alternated permanently with mutable types
# the last print statement outputs ['A', 'B', 'C', 'Hello']

'''
3. Write a function that takes in a list of words and returns a list of all words
longer than length 5
'''
def longer_than_five(l):
    long_words_list = []
    for i in l:
        if len(i) > 5:
            long_words_list.append(i)
    return long_words_list

print(longer_than_five(['hi', 'hello', 'genius', 'background', 'movies']))
            
'''
4. Write a function that takes in a list and removes the 2nd and 3rd element from the list.
'''
def remove_2_and_3(l):
    l.pop(2)
    l.pop(2)
    return l

print(remove_2_and_3(['A', 2, 'd', 'i', 45, 0]))

# removes indices 2 and 3 from list

'''
5. Write a function that takes in a list of characters and returns a string with 
all the characters combined.
Ex: ["a", "b", "c"] should return "abc"
'''
def combine_characters(l):
    x = ''
    for i in l:
        x += str(i)
    return x

print(combine_characters([2, 5, 'hi', 'there', 'YO']))
    
'''
6. Write a function that takes in a list of lists of integers. 
Return the inner list that has the highest sum.
Ex: [[1, 2, 3], [4, 5, 6]] should return [4,5,6]
'''

def max_sum(l):
    b = l[0]
    for i in l:
        if sum(i) > sum(b):
            b = i
    return b

print(max_sum([[1, 2, 3], [4, 5, 6]]))
