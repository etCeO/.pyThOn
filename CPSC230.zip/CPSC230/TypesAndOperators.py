# 9/6/23
# Types and Operators

# print(id(3))
num = 3
print(id(num))
2 + 4 + 5 + 1 # is an object, does not have a name

### Types

# int

x = 3
print(type(x))

# float

y = 3.5
print(type(y))

z = 2.0
print(type(z))

# boolean - TRUE or FALSE

b = True # must start with a capital letter
c = False 
print(type(b))
print(type(c))

# string

s1 = 'Pete'
s2 = "Pete"
s3 = '''Pete'''
print(type(s1))

print('Hello World')

s4 = "Pete's"
s4 = 'Pete\'s'
s5 = "Pete"

# list

l = [1, 2.5, s5, [1,2,3]]
print(type(l))

# dictionaries

pet = {'Name':'Roger', 'age': 7}
print(type(pet))

# syntax: {key:value , value pairs}

# sets - collection of unique objects

s = {1, 1, 1, 2, 3, 4, 5}
print(s)
l2 = [1, 1, 1, 2, 3, 4, 5]
print(l2)

print(type(s))

# constructors --> changing between object types

x = 9
print(type(x))
x = float(x)
print(type(x))
print(x)

x = str(x)
print(type(x))

# user input always comes in at type str
# info = input('Please enter a number:')
# info = int(info) # type casts into int
# print(type(info))

# info = int(input('please enter a number: '))
# print(type(info))

### Operators

# movie

# title = input(str())
# genre = input(str())
# year = input(int())
# length_hours = input(float())
# rating_stars = input(float())
# cast = {'Margot Robbie', 'Ryan Gosling', 'Kate McKinnon'}
# sets are for unique objects
# lists do not have to hold unique objects
character_names = ['Barbie', 'Ken', 'Barbie']

# movie dictionary
# movie_info = {}

# comparison operators

print(3 > 4)
print(4 < 5)
print(4 > 4)
print(4 >= 4)

print(3 == 3) # check for equality, use 2 ==
# = is used for assignment
# == is used for comparison
# print(x = 5) # this is creating an object x to the value 5

print(3 != 4) # != means not equal

# int operators

print(2+3)
print(13//4)
print(15 % 5)
print(2 ** 2)
print(12 % 6)
print(13//5)

x = 6
y = 5
print(x-y)
z = 4.5
print(x+z)
print(x / y)

# precedence practice
# What do you think the output of this expression will be?
# 2 + (3 * 4) + 3**2

print(2 + (3 * 4) + 3**2)

# shortcuts

x = 1
x = x + 1
x += 1

x = x * 12
x *= 12

# math module

import math

print(math.sqrt(16))

# round

print(round(1.234567, 2))
