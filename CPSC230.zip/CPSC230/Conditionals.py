# Conditionals



# if/else syntax with umbrella example
raining = False

if raining == True: # asking the question
    print('Bring an umbrella')

else: # otherwise
    print('No umbrella')  


# Exercise: Ask the user to enter an integer. Store this number as x. 
# Check to see if x is 74. If x is 74, print “Cool number!” 
# Otherwise, print “That’s a boring number”
    
x = int(input('Please enter a number: '))

if x == 74:
    print('Cool number!')

else:
    print('That\'s a boring number')


# Exercise: Students in a CPSC230 class have a quiz every Wednesday. 
# Write code that asks the user for the day of the week and then tell 
# them whether or not they have a quiz that day.

day = input('Please enter day: ')
day = day.lower()

if day == 'wednesday':
    print('Quiz')

else:
    print('No quiz')

# elif

day = input('Please enter day: ')
day = day.lower()

if day == 'monday':
    print('Quiz')
elif day == 'wednesday':
    print('ICP')
elif day == 'friday':
    print('Test')

else:
    print('Nothing')

print('Have a nice day!')

# Exercise: A student can get any of the following grades:
# A >= 90
# B >= 80
# C >= 70
# D >= 60
# F < 60
# Write code that asks users for their grade as a number and then outputs the 
# equivalent letter grade. Use conditional statements.

grade = float(input('Please enter grade: '))

if grade >= 90:
    print('A')
elif grade >= 80:
    print('B')
elif grade >= 70:
    print('C')
elif grade >= 60:
    print('D')
elif grade < 60:
    print('F')



# nested ifs


# Exercise: You wake up in the morning and have to decide whether or not you are hungry. 
# If you are hungry, you need to decide what to eat.

hunger = input('Are you hungry? (Yes/No): ')
hunger = hunger.lower()

if hunger == 'yes':
    food = input('Eggs, Waffles, or Cereal? : ')
    food = food.lower()

    if food == 'eggs':
        print('Eggs!')
    elif food == 'waffles':
        print('Yum')
    elif food == 'cereal':
        print('Do not forget milk')
    else:
        print('Invalid Input')

elif hunger == 'no':
    print('Do not eat anything')

else:
    print('Invalid Input')


# Exercise: Ask the user if they want to go swimming or for a run. 
# If they want to go swimming, ask if they want to wear SPF 30 or SPF 70 sunscreen.
# If they want to go running, ask if they want to wear shorts or leggings. 
# Print the user’s choice.
    
activity = input('Swim or Run? : ')
activity = activity.lower()

if activity == 'swim':
    spf = input('Spf30 or Spf70? : ')
    spf = spf.lower()

    if spf == 'spf30':
        print('Good luck!')

    elif spf == 'spf70':
        print('Good job!')

    else:
        print('okay')

elif activity == 'run':
    clothes = input('Shorts or Leggings? : ')
    clothes = clothes.lower()

    if clothes == 'shorts':
        print('Shorts!')

    elif clothes == 'leggings':
        print('Leggings :)')

    else:
        print('k cool :/')

else:
    print('wdym')
