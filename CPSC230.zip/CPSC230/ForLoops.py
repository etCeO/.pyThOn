# For Loops

# syntax

# loop through and print out the numbers 1 through 5

for i in range(1, 6): # 1 2 3 4 5
    print(i)


# for the numbers 1-10, print "even" for an even # and "odd" for an odd #

for j in range(1, 11):
    if j % 2 == 0:
        print(j, 'is Even')
    else:
        print(j, 'is Odd')



# for with different collections - strings, lists, range()

# strings
# lets count how many of each vowel we have

word = "supercalifragilisticexpialidocious"

a_count = 0
e_count = 0
i_count = 0
o_count = 0
u_count = 0

# create loop here

for letter in word:
    if letter == 'a':
        a_count += 1
    elif letter == 'e':
        e_count += 1
    elif letter == 'i':
        i_count += 1
    elif letter == 'o':
        o_count += 1
    elif letter == 'u':
        u_count += 1

print(a_count, e_count, i_count, o_count, u_count)


# lists
nums = [4, 5, 3, 6, 9, 10, 12, 15, 17]

# check if the items in nums are divisible by 3 or not

for num in nums:
    if num % 3 == 0:
        print(num, 'is divisible by 3')
    else:
        print(num, 'is not divisible by 3')

names = ["Abby", "Billy", "Charles", "Dave", "Emma"]

for name in names:
    print('Hello', name)

# continue with for loops
sentence = "good morning everyone"

# print all but the letter o

for letter in sentence:
    if letter == 'o':
        continue

    print(letter)

# break with for loops
# break when you find an n

for letter in sentence:
    if letter == 'n':
        break

    print(letter)

# nested for loops
# print out the multiplication tables for the numbers 2, 3, and 4

# numbers = [2, 3, 4]

for nums in range(2, 5):
    for num in range(1, 11):
        print(nums, '*', num, '=', num * nums)

    print()

