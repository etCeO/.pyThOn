'''
Your name: Ethan E. Lopez
Teammates names: George Guo, William
'''

'''
We will do question 0 together.
0. Create a dictionary called webkinz. This dictionary will have the following keys: name, health,
happiness, hunger, and energy. Write the following functions to go along with your dictionary:
1. welcome() - takes in a webkinz dictionary and allows the user to set the name. If the pet already
has a name, the user should not be able to update it
2. visit_doctor() - increases a webkinz' health by a given amount, n
3. cook() - takes in an amount of food, food. Decreases a webkinz' hunger by 10*food and decreases energy by 3*food
4. nap() - takes in a number of hours, hours, and increases energy by 10 * hours
5. play_with_pal() - takes in a number of minutes of play and increases happiness by 1.2 * minutes
'''

webkinz = {
    "name": "",
    "health": 10,
    "happiness": 50,
    "hunger": 100,
    "energy": 20
}

def welcome(webkinz):
    if webkinz["name"] == '':
        webkinz["name"] = input('Please enter a name: ')
    print('Welcome to webkinz', webkinz["name"])

welcome(webkinz)
print(webkinz)

def visit_doctor(webkinz, n):
    webkinz['health'] = webkinz['health'] + n

visit_doctor(webkinz, 10)
print(webkinz)

def cook(webkinz, food):
    webkinz['hunger'] -= 10 * food
    webkinz['energy'] -= 3 * food

cook(webkinz, 12)
print(webkinz)

def nap(webkinz, hours):
    webkinz['energy'] += 10 * hours

nap(webkinz, 1)
print(webkinz)

def play_with_pal(webkinz, minutes):
    webkinz['happiness'] += 1.2 * minutes

play_with_pal(webkinz, 15)
print(webkinz)

'''
1. Write a function shopping_list() that takes in a list of lists, recipes,
as an argument. The sublists contain ingredients for a recipe (see below). Using
sets, print out a list of unique ingredients needed by all of the recipes. (AKA
the ingredients you'd need on your shopping list)
'''

my_recipes = [["apples", "sugar", "cinnamon", "nutmeg", "cloves", "butter", "flour", "vodka"],
["ground beef", "beans", "lettuce", "cheese", "tomato", "sour cream", "avocado"],
["lettuce", "croutons", "parmesean", "anchovies", "mayo", "mustard", "worcestershire", "lemon"],
["lemon", "sugar", "flour", "vanilla", "butter", "eggs", "cloves"],
["eggs", "tomato", "bacon", "blue cheese", "lettuce", "cheese", "cucumber"]]

def shopping_list(lists):
    r = set()
    for i in lists:
        for j in i:
            r.add(j)
    return r

print(shopping_list(my_recipes))

'''
2. Create a dictionary called student. This dictionary should have the following keys: name, ID, major,
minor, current_classes, class_history. Write the following functions to use with your dictionary:
- update_name() - takes in a new name for the student and updates the value at the key name
- end_semester() - moves all of the student's current_classes into the class_history and clears current_classes
- update_major() - takes in a new major and updates accordingly
- update_minor() - takes in a new minor and updates accordingly
- new_semester() - takes in a list of new classes and stores that list in current_classes
'''

student = {'name': 'Ethan',
           'id':'7',
           'major':'Data Science',
           'minor':'Business',
           'current_classes':'Math, English, History',
           'class_history':''}

def update_name(name):
    student['name'] = name
    return student

print(update_name('Jose'))

def end_semester():
    student['class_history'] = student['current_classes']
    student['current_classes'] = ''
    return student

print(end_semester())

def update_major(major):
    student['major'] = major
    return student

print(update_major('Computer Science'))

def update_minor(minor):
    student['minor'] = minor
    return student

print(update_minor('English'))

def new_semester(new_classes):
    student['current_classes'] = new_classes
    return student

print(new_semester(['Bio, Art, Pysch']))


'''
3. From story below, make a dictionary that counts the number of each letter
(a-z, case doesn't matter.). Then print out the mean count of the vowels.
'''

story = '''
True! — nervous — very, very dreadfully nervous I had been and am; 
but why will you say that I am mad? 
The disease had sharpened my senses — 
not destroyed — not dulled them. 
Above all was the sense of hearing acute. 
I heard all things in the heaven and in the earth. 
I heard many things in hell. 
How, then, am I mad? Hearken! 
and observe how healthily — 
how calmly I can tell you the whole story.

It is impossible to say how first the idea entered my brain; 
but once conceived, it haunted me day and night. 
Object there was none. Passion there was none. 
I loved the old man. He had never wronged me. 
He had never given me insult. 
For his gold I had no desire. 
I think it was his eye! 
yes, it was this! 
One of his eyes resembled that of a vulture — 
a pale blue eye, with a film over it. 
Whenever it fell upon me, my blood ran cold; 
and so by degrees — very gradually — 
I made up my mind to take the life of the old man, 
and thus rid myself of the eye forever.
'''
vowel_count = {}
count = {}

for i in story:
    if i.isalpha():
        count[i] = count.get(i, 0) + 1
        if i in 'aeiou':
            vowel_count[i] = vowel_count.get(i, 0) + 1

print(count)
print(vowel_count)

s = 0

for i in vowel_count.values():
    s += i

m = s / len(vowel_count)

print(m)

'''
4. Create a function, dictionary_maker() that takes in two arguments: keys (a list of
keys for a dictionary), and values (a list of values for the dictionary).
Raise an error if keys and values are different lengths.
Create a dictionary with the key, value pairs and return the dictionary.
Call your function.
'''

def dictionary_maker(keys, values):
    if len(keys) != len(values):
        raise IndexError ('the keys and values are different lengths')
    new_dictionary = {}
    for i in range(0, len(keys)):
        new_dictionary[keys[i]] = values[i]
    return new_dictionary

keys = ['Hi', 'grade', 'happiness']
values = ['g', 'A', 21]

print(dictionary_maker(keys, values))

'''
5. Write a function called calculate_grade that takes a dictionary of student grades as an argument.
Using the weights below, calculate the weighted final grade for the given student.
- assignments: 30%
- participation: 25%
- challenges: 5%
- exam1: 10%
- exam2: 10%
- finalexam: 20%
Your function should return (not print) the calculated grade.

Call your function with both student A and student B
'''

studentA = {"assignments": 89,
"participation": 70,
"challenges": 100,
"exam1": 90,
"exam2": 75,
"finalexam": 90}

studentB = {"assignments": 75,
"participation": 90,
"challenges": 100,
"exam1": 80,
"exam2": 85,
"finalexam": 75}

def calculate_grade(s):
    f = 0
    f += s['assignments'] * 0.3
    f += s['participation'] * 0.25
    f += s['challenges'] * 0.05
    f += s['exam1'] * 0.1
    f += s['exam2'] * 0.1
    f += s['finalexam'] * 0.2
    return f

print(calculate_grade(studentA))
print(calculate_grade(studentB))

'''
6. Using the three list below, figure out which shows/movies are
- only on netflix and no other platform
- only on hulu and no other platform
- on both netflix and hulu
- are on netflix, hulu, and amazon_prime
- are unique to their platform (e.g. shows/movies that only appear on one platform)
'''

netflix = ["Seinfeld", "The Great British Baking Show", "The Good Place", "Greys Anatomy", "Friends",
"You", "Arrested Development", "The Witcher", "Riverdale", "Uncut Gems", "The Lorax", "Breaking Bad", "The Office"]
hulu = ["Seinfeld", "Greys Anatomy", "Friends", "The Good Doctor", "The Office", "Bob's Burgers", "Cougar Town", "The Simpsons",
"Superstore", "It's Always Sunny in Philidelphia", "Desperate Housewives", "Futurama", "Frasier", "Shrek", "Parasite"]
amazon_prime = ["Seinfeld", "Spongebob", "Dexter", "Midsommar", "The Princess Bride", "Cast Away", "The Tomorrow War", "House MD", "Fight Club",
"Mrs. Doubtfire", "The Office", "The Simpsons", "Friends"]

n = set(netflix)
h = set(hulu)
a = set(amazon_prime)

print(n - h - a)
print(h - n - a)
print(n & h)
print(n & h & a)
print(n^h^a)

'''
7. Write some code to ask two friends their favorite music artists,
and then print out a message telling them which artists they both said they like
'''

f1 = set()
f2 = set()

while True:
    a = input('Type your favorite music artists or hit enter: ')
    if a == '':
        break
    f1.add(a)

while True:
    a = input('Type your favorite music artists or hit enter: ')
    if a == '':
        break
    f2.add(a)

print('You and your friend both like', f1 & f2)