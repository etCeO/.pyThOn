# Mutable vs immutable behavior in functions, multiple returns


# immutable objects - id check

def my_func(x):
    print(x)
    x = 'Hello'
    print(x)

x = 'Hi'
print(x)
my_func(x)
print(x)

# mutable objects - id check

def my_func2(y):
    print(y)
    y.pop()
    print(y)

# what happens in functions does not stay in functions if it is a mutable type
# changes are reflected in both local and main name spaces
    
y = [1, 2, 3, 4]
print(y)
my_func2(y)
print(y)

# when dealing with a mutable type, like a list...
# modifications made in functions ARE reflected

# take 5 minutes to practice
# What will the output of this code function be?
def practice(l, s):
    print(l)
    l.append(10)
    l.pop(3)
    print(s)
    s = "No"
    print(s)

l = [10, 20, 30, 40, 50]
s = "Yes"
practice(l, s)
print(l)
print(s)

# returning multiple objects



# multiple return - 3 dice
# write a function that "rolls" 3 dice and returns the results

import random

def roll_3():
    roll1 = random.randint(1, 6)
    roll2 = random.randint(1, 6)
    roll3 = random.randint(1, 6)
    return roll1, roll2, roll3

roll = roll_3()
print(roll)
print(type(roll))
print(roll[0])

# multiple assignment

roll1, roll2, roll3 = roll_3()
print(roll1)

# name_splitter() - 
# Write a function that takes in one string in the format
# "FirstName LastName"
# and return 2 separate objects, one for first and one for last
# call your function and store first and last separately

def name_splitter(full_name): # 'First Last'
    full_name = full_name.split()
    first = full_name[0]
    last = full_name[1]
    return first, last

# Version A
first, last = name_splitter('Ethan Lopez')
print(first)
print(last)
# Version B
name = name_splitter('Ethan Lopez')
first = name[0]
last = name[1]
print(first)
print(last)
