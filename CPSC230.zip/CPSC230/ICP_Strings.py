'''
Your name: Ethan E. Lopez
Your teammates names: George, William, Ethan B
'''


# Question 1. Using a for loop, count the number of spaces, periods, and commas in the speech below
# Then do it with a while loop

speech = '''Two roads diverged in a yellow wood,
And sorry I could not travel both
And be one traveler, long I stood
And looked down one as far as I could
To where it bent in the undergrowth;
Then took the other, as just as fair,
And having perhaps the better claim,
Because it was grassy and wanted wear;
Though as for that the passing there
Had worn them really about the same,
And both that morning equally lay
In leaves no step had trodden black.
Oh, I kept the first for another day!
Yet knowing how way leads on to way,
I doubted if I should ever come back.
I shall be telling this with a sigh
Somewhere ages and ages hence:
Two roads diverged in a wood, and I—
I took the one less traveled by,
And that has made all the difference.'''

spaces = 0
periods = 0
commas = 0

for i in speech:
    if i == ' ':
        spaces += 1
    elif i == '.':
        periods += 1
    elif i == ',':
        commas += 1
    
print(spaces, 'spaces,', periods, 'periods, and', commas, 'commas')

spaces = 0
periods = 0
commas = 0
x = 0

while x < (len(speech)):
    if speech[x] == ' ':
        spaces += 1
        x += 1
    elif speech[x] == '.':
        periods += 1
        x += 1
    elif speech[x] == ',':
        commas += 1
        x += 1
    x += 1

print(spaces, 'spaces')
print(periods, 'periods')
print(commas, 'commas')

# 2. Use string slicing to print only "Edgar" from the following strings
s1 = "Edgar's favorite color is purple"

print(s1[:5])

s2 = "My name is Edgar"

print(s2[11:])

s3 = "Good Morning, Edgar"

print(s3[14:])

s4 = "ragdE"

print(s4[::-1])

s5 = "r2a3g6d6E"

print(s5[::-2])

'''
3. Ask the user for a word as input and store it in a variable, palindrome.
Then, check whether their word is a palindrome (the same forwards and backwards,
like the word kayak). If it is, print out a message informing them they found a palindrome.
'''
while True:
    p = input('Please enter a word: ')
    p = p.lower()
    if p == p[::-1]:
        print('Found a palindrome!')
        break
    print('Not a palindrome')

'''
4. A friend has left you a hidden message in the string below, but they've
told you that to find it, you have to look at every other letter starting at
the END of the string and moving towards the beginning. Luckily you know how
to use Python for that. Print out their message below.
'''


'''
5. Using a while loop to loop through the indices (remember indexing starts
at 0 in python), write some code that counts the number of vowels in a user
inputted string. Make sure you use the in operator.
'''
s = input('Please enter a word: ')
vowels = 0
i = 0

while i < (len(s)):
    if s[i] in 'aeiou':
        vowels += 1
        i += 1
    i += 1

print(vowels, 'vowel in this word')

'''
6. Pretend your user is a Club Penguin player. Ask the user to input a message.
Use the in operator to check if any of the following "bad words" are in the message
a Club Penguin user is trying to type. If any of them are, print "You're BLOCKED".
Otherwise, print the message as is.
BAD WORDS:
- dang
- gosh
- shoot
- fork
- bench
'''

m = input('Please enter a message: ')
m = m.lower()

if ('dang' in m) or ('gosh' in m) or ('shoot' in m) or ('fork' in m) or ('bench' in m):
    print("You're BLOCKED")
else:
    print(m)


'''
7. Let's do a new madlib program. Use the string madlib and the.replace(old,new) 
method to replace the ADJECTIVE, VERBS, NOUNS, etc in the string with user entered strings.
'''

madlib = '''Two *NOUN1*, both alike in dignity,
In fair *PLACE1*, where we lay our scene,
From ancient *NOUN2* break to new mutiny,
Where civil blood makes civil hands unclean.
From forth the fatal loins of these two foes
A pair of star-crossd *NOUN3* take their life;
Whole misadventured piteous overthrows
Do with their *NOUN4* bury their parents strife.
The fearful passage of their *ADJECTIVE2* love,
And the continuance of their parents rage,
Which, but their childrens end, nought could *VERB1* ,
Is now the *NUMBER* hours traffic of our stage;
The which if you with *ADJECTIVE3* *BODYPART* attend,
What here shall *VERB2*, our toil shall strive to mend.'''

noun1 = input('Please enter first noun: ')
place1 = input('Please enter first place: ')
noun2 = input('Please enter second noun: ')
noun3 = input('Please enter third noun (plural): ')
noun4 = input('Please enter fourth noun: ')
adjective1 = input('Please enter first adjective: ')
verb1 = input('Please enter first verb (present tense): ')
number = input('Please enter a number: ')
adjective2 = input('Please enter a second adjective: ')
bodypart = input('Please enter a body part: ')
verb2 = input('Please enter a second verb (present tense): ')

madlib = madlib.replace('*NOUN1*', noun1)
madlib = madlib.replace('*PLACE1*', place1)
madlib = madlib.replace('*NOUN2*', noun2)
madlib = madlib.replace('*NOUN3*', noun3)
madlib = madlib.replace('*NOUN4*', noun4)
madlib = madlib.replace('*ADJECTIVE2*', adjective1)
madlib = madlib.replace('*VERB1*', verb1)
madlib = madlib.replace('*NUMBER*', number)
madlib = madlib.replace('*ADJECTIVE3*', adjective2)
madlib = madlib.replace('*BODYPART*', bodypart)
madlib = madlib.replace('*VERB2*', verb2)

print(madlib)


'''
8. SpOnGeMoCk (like from this meme:
https://twitter.com/TheSpongeMock/status/864971797036400645)
is when every other letter is capitalized, and every other letter is lowercase. Ask
the user for a string, and change it into SpongeMock case!
'''

# input = input('Please enter a message: ')

message = input('Please input a message: ')
index = 0
spongemocked = '' # variable to store spongemocked message

while index < len(message):
    if index % 2 == 0:
        spongemocked = spongemocked + message[index].upper()
    else:
        spongemocked = spongemocked + message[index].lower()
    index += 1

print(spongemocked)
