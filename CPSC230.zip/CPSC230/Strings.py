# Strings

# syntax - 3 ways

s1 = 'Hello'
s2 = "Hello"
s3 = '''Hello'''

print(type(s1))

4

'''
multi
line
comment
'''

# typecasting to a string
my_num = 4

print(type(my_num))

my_num = str(my_num)

print(type(my_num))

# whitespace - 3 types

s4 = ' '
print(len(s4))

s5 = '\tHello'
print(s5)
print(len(s5))

s6 = 'Hello\nHi'
print(s6)
print(len(s6))

print('hey', end = '\n')
print('hey')

print('yay', end = '')
print('yay')

# string indexing - grab an individual character from a string

my_string = "Apples and Bananas"

print(my_string[5])

# string slicing - grab multiple characters from a string

print(my_string[0:6])
print(my_string[7:10])

# string slicing - no start index specified

print(my_string[:6])

# string slicing - no end index specified

print(my_string[11:])

print(my_string[:])
print(my_string)

# start_index:end_index:how_to_move_through_string --> - and numbers

# var_name[start_index:end_index:*]
print(my_string[::-1]) #string goes backwards
print(my_string[::2]) #whole numbers allow to skip letters
print(my_string[::1]) #prints my_string
print(my_string[::-2])

# string operations
string1 = "cat"
string2 = "dog"

# + --> used for concatenation

print(1+1)
print('1'+'1')
print(string1 + string2)
print('fish' + '1')
num = 1
num = str(num)
print('fish' + num)

# * --> used for repetition

print(string1 * 4)
print(string2 * 3)
# can't do string1 * string2

# in
vowels = "aeiou"

print('e' in vowels) # True
print('r' in vowels) # False
print('eu' in vowels) # False
print('ae' in vowels) # True
print('e' in vowels and 'u' in vowels) # True

letter = 'a'

if letter in 'aeiou':
    print('Found a vowel!')

else:
    print('Found a consonant!')

letter1 = 't'

if letter1 not in 'aeiou':
    print('Found a consonant!')

# strings are immutable

s1 = 'Hello'
print(s1[0]) # H
# s1[0] = 'J' - RUNTIME ERROR
# you cannot individually change the items in your string

# string comparison

print("apple" == "apple") # True - because all characters are the same
print("apple" > "banana") # "a" > "b" FALSE b > a
print("shoe" < "shoes") # shoes > shoe {longer > short} - TRUE
print("Apple" > "apple") # lowercase > UPPERCASE "A" < "a" FALSE

print('penguin' > 'penny') # "g" > "n" is FALSE

print('P' > 'a') # all lowercase > ANY UPPERCASE

# string methods

# .upper() and .lower()

s1 = 'ELephanT'

print(s1.upper())
print(s1.lower())

s1 = s1.lower()
print(s1)

word = 'GoOsE'

for letter in word.lower():
    if letter in 'aeiou':
        print(letter)

# .isalpha(), .isdigit(), .isupper(), .islower() - all return True or False

# .isalpha - TRUE if all are letters
        # False otherwise

print('cat2'.isalpha())
print('Hello'.isalpha())

# .isdigit - TRUE if all are numbers
        # False otherwise

print('1234'.isdigit())
print('12345!'.isdigit())
print('-100'.isdigit()) # because '-' is not a number

print('Hello'.isupper()) #False
print('hi'.islower()) #True
print('juese!'.islower()) # True
print('HI2'.isupper()) # True

#.upper transitions
#.isupper checks true or false

# .islower and .isupper are exceptions for extra characters

# .replace(old, new)

s1 = 'Jesus!'

print(s1.replace('s', 'S', 1))
print(s1.replace('J', 'j'))
print(s1.replace('!', '?'))


# kids bop challenge - change these song lyrics to be kids bop appropriate

lyrics = '''
This is the last $20 I got
But I'ma have a good time ballin' or out
Tell the bartender, line up some shots
'Cause I'ma get loose tonight

She's on fire, she's so hot
I'm no liar, she burn up the spot
Look like Mariah, I took another shot
Told her drop, drop, drop, drop it like it's hot
'''
# chaining methods - two methods in the same line of code

lyrics = lyrics.replace('shot', 'water').replace('bartender', 'cashier')
lyrics = lyrics.replace('hot', 'fun')

print(lyrics)

# .startswith(x) - returns boolean - True if string starts with x, False otherwise

s1 = 'elliE'

print(s1.startswith('e'))
print(s1.startswith('ell'))

# grab a number from the user
# check to see if it's negative

number = input('Please enter a number: ')
n = str(number)

if n.startswith('-'): 
    if n[1:].isdigit():
        print('This is a negative number :)')

    else:
        print('This is not a number')

else:
    print('Not a negative number!')

# .strip()

white_space_variable = "\t\nI am a variable and I have lots of whitespace    \t"

print(white_space_variable.strip())

# removes whitespaces from beginning to the end and not anywhere in between

# .split()

sentence = "This is my sentence and I want to split it"

list1 = sentence.split()
print(list1)

sentence = "This_is_my_sentence_and_I_want_to_split_it"

list1 = sentence.split('_')
print(list1)

# chaining methods

s1 = s1.replace('e', 'j').upper()
print(s1)

print('hello?'.isalpha())
