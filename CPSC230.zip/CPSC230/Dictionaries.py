# Dictionary notes

examp = {"Name": "Katherine", "Age": 72}

# Indices

person_dict = {'Name': 'Bart', 'Age': 21, 'Favorite Number': 21, 'Classes': ['MATH 111, CPSC 231']}

print(person_dict)

# you CANNOT have repeating keys, all should be unique
# you CAN have repating values

# adding to dictionary

# dictionaries are MUTABLE
# reassigning in a dictionary

# dictionaries are UNORDERED!!!

person_dict['Age'] = 22
print(person_dict)

# add new key value pair

person_dict['ID'] = 72819
print(person_dict)

# looping through dictionaries - 3 ways

# 1
# Iterate over only keys

for key in person_dict.keys():
    print(key)
# .keys() returns all the keys
    
for key in person_dict:
    print(key)

#2 
# Iterate over only values
    
for value in person_dict.values():
    print(value)
# .values() returns all the values
    
#3
# Iterate over keys and values
    
for item in person_dict.items():
    print(item)
    print(item[0]) #prints keys
    print(item[1]) #print values
# .items() returns keys and values as tuples

for key, value in person_dict.items():
    print(key, value)

# .get()

tup = ('a', 'b')
var1, var2 = tup

print(person_dict.get('Major', 'Undecided'))
print(person_dict)

person_dict['Major'] = person_dict.get('Major', 'Undecided')
print(person_dict)

# Bart just got a new pet

person_dict['Pet Count'] = person_dict.get('Pet Count', 0) + 1
print(person_dict)

# counting characters in a string using a dictionary

poem = '''Shall I compare thee to a summer’s day?
Thou art more lovely and more temperate.
Rough winds do shake the darling buds of May,
And summer’s lease hath all too short a date.
Sometime too hot the eye of heaven shines,
And often is his gold complexion dimmed;
And every fair from fair sometime declines,
By chance, or nature’s changing course, untrimmed;
But thy eternal summer shall not fade,
Nor lose possession of that fair thou ow’st,
Nor shall death brag thou wand'rest in his shade,
When in eternal lines to Time thou grow'st.
    So long as men can breathe, or eyes can see,
    So long lives this, and this gives life to thee.
'''

count = {}

for letter in poem:
    count[letter] = count.get(letter, 0) + 1

print(count)


# rolling dice

# simulate 1000 dice rolls
# use a dictionary to keep track of how many of each number you roll

import random

dice_count = {1:0, 2:0, 3:0, 4:0, 5:0, 6:0}

for i in range(0, 1000):
    r = random.randint(1, 6)
    dice_count[r] += 1

print(dice_count)

# code names
# replace the names in the string below with their code names

sentence = "Jim works with Paul and Lily."
code_names = {"Jim": "John", "Paul": "Pete", "Lily": "Lola"}

sentence = sentence.replace('Jim', code_names['Jim'])
sentence = sentence.replace('Paul', code_names['Paul'])
sentence = sentence.replace('Lily', code_names['Lily'])

print(sentence)