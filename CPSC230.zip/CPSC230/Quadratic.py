
# Ethan E. Lopez
# 002425516
# etlopez@chapman.edu
# CPSC 230 - Section 2
# Program Assignment 1

coefficient_a = input('Coefficient a: ')
a = float(coefficient_a)
coefficient_b = input('Coefficient b: ')
b = float(coefficient_b)
coefficient_c = input('Coefficient c: ')
c = float(coefficient_c)

solution1 = ((b * -1) + (((b ** 2) - (4 * a * c)) ** 0.5)) / (2 * a)
s1 = round(float(solution1), 2)
solution2 = ((b * -1) - (((b ** 2) - (4 * a * c)) ** 0.5)) / (2 * a)
s2 = round(float(solution2), 2)

print(f'The roots of the function are {s1} and {s2}.')
