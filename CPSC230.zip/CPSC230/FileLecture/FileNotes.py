# Before following along, please download the following files and put them in your CPSC230 folder:
# - preamble.txt
# - students.csv

# reading files
# create a connection with your document

f = open('preamble.txt', 'r')

for line in f:
    print(line)

f.close()

# loop through the lines and print them

f = open('preamble.txt', 'r')
preamble = ''
for line in f:
    preamble += line.strip() + ' '

print(preamble)

f.close()

# loop through lines, but save in a string



# close our connection to the file



# 404 - FileNotFoundError

# f = open('Hello.txt', 'r')


# writing files
# create a connection with this document (overwrite if it exists)

song = open('lyrics.txt', 'w')

# write lines to doc
# .write() is another file object method
song.write("You know you love me, I know you care\n")
song.write("Just shout whenever, and I'll be there\n")
song.write("You are my love, you are my heart\n")
song.write("And we will never, ever, ever be apart\n")

song.close()

# close our connection to the file



# what happens if this file already exists?

# song = open('lyrics.txt', 'w')
# song.write('hello')
# song.close()

# appending files

# open using a instead of w

song = open('lyrics.txt', 'a')

# write lines to doc
song.write("\n")
song.write("Are we an item? girl, quit playin'\n")
song.write("'We're just friends', what are you sayin'?\n")
song.write("Said, 'There's another', and looked right in my eyes\n")
song.write("My first love broke my heart for the first time, and I was like\n")

song.close()

# close our connection to the file



# reading AND writing files
# lets add line numbers to the preamble

inp = open('preamble.txt', 'r')
out = open('output.txt', 'w')

line_number = 1

for line in inp:
    out.write(str(line_number) + '.' + line)
    line_number += 1

# don't forget to close both connections
inp.close()
out.close()

# with open

with open('preamble.txt', 'r') as f:
    for line in f:
        print(line)

'''
Open the song file
Read through the file
Find words that start with i
Save them in a list called i_words 
'''

f = open('lyrics.txt', 'r')

lyrics = ''
for line in f:
    lyrics += line

lyrics = lyrics.split()

print(lyrics)

i_words = []
for word in lyrics:
    if word.lower().startswith('i'):
        i_words.append(word)

print(i_words)

# csv

import csv

# open in r mode

f = open('students.csv', 'r')

# for line in f:
    # print(line)

csv_object = csv.reader(f, delimiter = ",")

student_list = []
for line in csv_object:
    student_list.append(line)

print(student_list)

# read all of the info in the file
# save it into a list called student_info


# find the average GPA of all of the students

gpa_sum = 0

for student in student_list[1:]:
    gpa_sum += float(student[4])

gpa_avg = gpa_sum / (len(student_list) - 1)

print(gpa_avg)

# most common major

all_majors = []
majors = []

for student in student_list[1:]:
    all_majors.append(student[3])

print(all_majors)

for major in all_majors:
    if major not in majors:
        majors.append(major)

print(majors)

for i in majors:
    print(i, all_majors.count(i))
    


