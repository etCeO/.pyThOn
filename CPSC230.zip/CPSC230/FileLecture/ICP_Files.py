'''
Your name: Ethan E. Lopez
Teammate(s) names: George Guo, William
'''

'''
1. When you call open on a file, and then loop through it, what are we looping
through? characters? lines? paragraphs?
'''

# we are looping through lines when we call open a file

'''
2. Explain the difference between "r" w" and "a" modes.
'''

# 'r' is read only mode, so this reads the file that currently exists
# 'w' is write only mode, so this allows you to write a new file and clear pre-existing information if the file exists
# 'a' adds new information in write mode to an existing file or creates a new file

'''
3. Open the file beyonce.csv and print out the mean danceability for her songs.
'''

import csv

f = open('beyonce.csv', 'r')
csv_object = csv.reader(f, delimiter=',')

beyonce_list = []

for i in csv_object:
    beyonce_list.append(i)

dance = 0

for i in beyonce_list[1:]:
    dance += float(i[2])

d = dance / (len(beyonce_list) - 1)

print(d)

f.close()


'''
4. Open the lyrics.txt file we created and count the 
number of punctuations ".?!,'"
'''

f = open('lyrics.txt', 'r')
s = ''

for line in f:
    s += str(line)

p = {'.': 0, '?': 0, '!': 0, ',': 0, "'": 0}

for i in s:
    if i in p:
        p[i] += 1

print(p)

f.close()

'''
5. Write a function, letter_counter() that takes in the name of a file as a string (fn),
and a letter (letter) as arguments and returns the number of times that character
occurs in the file (regardless of case).
Using the preamble.txt file, count the number of c's, e's, and s's in the file.
'''
def letter_counter(fn):
    f = open(fn, 'r')
    s = ''
    for line in f:
        s += str(line)
    s = s.lower()
    d = {'c': 0, 'e': 0, 's': 0}
    for i in s:
        if i in d:
            d[i] += 1
    f.close()
    return d

print(letter_counter('preamble.txt'))

'''
6. Write a try/except block that attempts to open beyonce.csv. Throw an appropriate
error if the file can't be found.
'''

try:
    f = open('beyonce.csv', 'k')
except ValueError as e:
    print(e)

