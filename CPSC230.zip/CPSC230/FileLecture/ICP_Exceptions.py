'''
Your name: Ethan E. Lopez
Teammates names: George Guo, William
'''


'''
1. Write a function, list_inserter() that takes in a list, l, an object, x, and an index, i, as
arguments. The function should take x (which might be a string, an int...etc) and insert it into
the list l at index i.
Raise a ValueError if the index i is greater than len(l) (aka if they're trying to insert x into an
index that can't exist). Make sure you include a useful error message!
'''
def list_inserter(l, x, i):
    l.insert(i, x)
    if i > len(l):
        raise ValueError('That index does not exist!!!')
    return l

print(list_inserter([2, 4, 6], 8, 0))
# print(list_inserter([2, 4, 6], 20, 21))

'''
2. Write a function, story_reader(), which takes in an argument, f, which is a
filename/filepath to a text file containint a book/story. Use try and except
to account for the case when someone tries to give a value for f that does not
exist. If they give you a non-existant file, print out a message telling them,
and then open the file "boringStory.txt" instead (if you want to test this out
make sure you create a  file called "boringStory.txt" on your computer.)
'''
def story_reader(f):
    try: 
        g = open(f, 'r')
        for line in g:
            print(line)
    except FileNotFoundError:
        print('No such file exists')
        g = open('boringStory.txt', 'r')
        for line in g:
            print(line)
    except OSError:
        print('Do not use an integer')
        g = open('boringStory.txt', 'r')
        for line in g:
            print(line)
    g.close()

print(story_reader('hi.txt'))
print(story_reader(8))
print(story_reader('lyrics.txt'))

'''
3. Modify story_reader to account for both FileNotFound errors (when the file doesn't exist)
and an OSError when someone gives you a value for f that is not a filename (like an int).
Make sure to tell the user what their issue was.
'''



'''
4. Write some code that prompts a user to keep entering numbers until they type enter. Store these numbers
as floats in a list. If they enter something that is not a number, raise an appropriate error.
'''
number_list = []

while True:
    try:
        n = input('Please enter a number: ')
        if n == '':
            break
        n = float(n)
        number_list.append(n)
    except ValueError:
        print('Invalid Input')

print(number_list)
    


        



