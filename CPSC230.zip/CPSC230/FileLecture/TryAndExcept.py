# Syntax

# print('abc' + 17)
print('hello')

# try:
#     # code you want to try running
# except:
#     # do this code if the above code causes an error
while True:
    try:
        num = int(input('Please enter a number: '))
        print(num * 5)
        break
    except:
        print('Hey, that was not a number')


# Divide by 0 example
# What we would do before:

num = input("Enter a non-zero, positive number please. ")
bad_num = True
while bad_num:
    if not num.strip("-").isnumeric():
        print("That is not a number. Please try again. ")
        num = input("Enter a non-zero, positive number please. ")
    elif int(num) <= 0:
        print("That is not a positive number. Please try again.")
        num = input("Enter a non-zero, positive number please. ")
    else:
        num = int(num)
        bad_num = False

print(10/num)


# Now using try and except
# ValueError if the user enters not a number
# ZeroDivisionError if the user enters 0

while True: 
    try:
        num = int(input('Please enter a number: '))
        print(10/num)
        break

    except:
        print('Hey, that was not a non zero number')

# Divide by 0 - multiple exceptions
while True:
    try:
        num = int(input('Please enter a number: '))
        print(10/num)
        break
    except ValueError:
        print('Hey, that was not a number')
    except ZeroDivisionError:
        print('Do not enter 0')
    except:
        # if using generic concept, it must go below all other exceptions
        print('Something went wrong')

# multiple exceptions - list index
# create a list named l1
# ask the user for an index
# print out the statement from l1 at the given index
    
# user could not enter an out of bounds index
# user could not enter a number

try:  
    l1 = [10, 9, 8, 7, 6, 5]
    index = int(input('Please enter an index: '))
    print(l1[index])
except IndexError as e:
    print('That was not a valid index.')
    print(e)
except ValueError:
    print('That was not even a number...')



# Raising errors

def direction_getter():
    print("Hello! You will choose a direction to go")
    direction = input("Would you like to go N/S/E/W? ")
    direction = direction.upper()
    if direction not in ["N", "S", "E", "W"]:
        return 'Hey, that was not a valid direction'
    else:
        return direction

while True:
    d = direction_getter()
    if d.upper() in 'NSEW':
        break
    else:
        print(d)

def direction_getter2():
    print("Hello! You will choose a direction to go")
    direction = input("Would you like to go N/S/E/W? ")
    direction = direction.upper()
    if direction.isdigit():
        raise TypeError('That is not even a letter')
    elif direction not in ["N", "S", "E", "W"]:
        raise ValueError('That is not a real direction...')
    else:
        return direction
    
# direction_getter2()


# try and accept and raising errors

try:
    d = direction_getter2()
    print('Enjoy your trip to the', d)
except ValueError as e:
    # exception is a variable who's value is the personalized error message
    print(e)
except TypeError as e:
    print(e)

# finally - something you want to ALWAYS happen

try:
    f = open('lyrics.txt', 'r')
    for line in f:
        print(line)
    f.close()
except:
    print('Something went wrong')
finally:
    print('Have nice day')

