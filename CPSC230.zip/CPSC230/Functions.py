# Functions

# Function definition - syntax

# name_printer() - write a function that takes a name as an argument and prints it

def name_printer(name):
    print('Hi', name)

name_printer('Jesus')
name_printer('Yo MAMA')
name_printer('Hello')

# num_adder() - write a function that adds 1 + 1 and returns the value

def num_addy():
    d = 1 + 1
    return d

result = num_addy()
print(result)

def num_adder(a, b):
    c = a + b
    print(c)

a = int(input('Please enter 1st number: '))
b = int(input('Please enter 2nd number: '))

print(a, b)
num_adder(a, b)


# name_splitter() - write a function that takes a full name as one string,
# and prints last name, first name

def name_splitter(full_name):
    full_name = full_name.split()
    print(f'{full_name[1]}, {full_name[0]}')

name_splitter('Ethan Lopez')
name_splitter('Jane Doe')



# squared() - write a function that returns the square of a given number

def squared(number):
    number = number ** 2
    return number

number = int(input('Please enter a number: '))

print(number)
print(squared(number))


# namespaces
# add_one - write a function that takes in a number, num, adds 1 to it, and prints it

def add_one(num):
    num += 1
    print(num)

num = input('Please enter a number: ')
num = int(num)

print(num)
add_one(num)


# greater_than_10() - write a function that returns True if a given number is > 10, False otherwise

def greater_than_10(n):
    if n > 10:
        return True
    else:
        return False
    
print(greater_than_10(14))
print(greater_than_10(3))

# Try on your own
# 1. Write a function pal_checker() that takes in a string, s,
# and returns True if s is a palindrome, and False if s is not

def pal_checker(s):
    s = s.lower()
    if s == s[::-1]:
        return True
    else:
        return False
    
s = input('Please enter string: ')

print(pal_checker(s), 'palindrome')


# 2. Write a function, sphere_volume() that takes the radius of a sphere and returns the volume. 
# Use the value of pi from the math library.
# Volume of a sphere = 4/3 * pi * r^3

import math

def sphere_volume(r):
    v = (4/3) * math.pi * (r ** 3)
    return v

r = int(input('Please enter radius: '))

print(sphere_volume(r), 'is the volume of the sphere')

# multiple arguments
# write a function called calc_product() that takes two numbers and returns the product

def calc_product(x, y):
    p = x * y
    return p

print(calc_product(4, 2))

# default arguments
# Write a function called menu_printer() that has a pre-set 3 course menu,
# but allows the user to pass in other choices if desired. 
# Print the menu to the user.

def menu_printer(app = 'salad', entree = 'chicken', dessert = 'cake'):
    print('Enjoy', app, 'for a starter')
    print('Enjoy', entree, 'for main')
    print('Enjoy', dessert, 'for dessert')

menu_printer()
menu_printer('Chips')
menu_printer(dessert = 'Chips')

# everything without defaults goes first
# defaults go after

# returns area of a rectangle given two sides
# set two sides equal to 3

def rectangle_area(s1 = 3, s2 = 3):
    a = s1 * s2
    return a

print(rectangle_area(4, 6))
print(rectangle_area(4))
print(rectangle_area())
print(rectangle_area(s2 = 5))