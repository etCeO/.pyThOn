
# 1
# write a loop that takes a user defined number of iterations and prints out 'hey' that many times

i = int(input('Please enter a number of times to say hey: '))
x = 0

while x < i:
    print('Hey')
    x += 1

#2
# write a nested conditional that asks the user to go to London or Paris
# if London, ask if they want to go to Big Ben or Buckingham Palace
# if Paris, Eiffel Tower or The Louvre
# prompt them until they enter the proper city input (use while)
    
while True:
    p = input('Would you like to go to London or Paris? : ') 
    p = p.lower()
    if p == 'london':
        l = input('Would you like to go to Big Ben or Buckingham Palace? : ')
        l = l.lower() 
        if l == 'big ben':
            print('Have a great time at Big Ben!!!')
            break
        elif l == 'buckingham palace':
            print('Have a swell journey at Buckingham!')
            break
        else:
            print('Invalid Input') 
    elif p == 'paris':
        l = input('Would you like to go to Eiffel Tower or The Louvre? : ')
        l = l.lower()
        if l == 'eiffel tower':
            print('The great HIGH-light of your life ;)')
            break
        elif l == 'the louvre':
            print('Have a wonderful evening at The Louvre!')
            break
        else:
            print('Invalid Input')
    else:
        print('Invalid Input')
              

# 3
# give an example of a time you would need to use an elif
    
# elif statements are used when checking multiple conditions
# for example, if you do different things for whether something is hot or when something is cold
# elifs are the second, third, etc. choices after the first choice, the if
        
# give an example of a time where you would need to use a nested if
        
# nested ifs are used for conditions inside conditions
# for example, if you say you like the cold weather vs. hot weather, you will either sleep or drink hot cocoa
# for choices inside choices like these, nested ifs are required
            
# 4
# when do I use a while vs. a for loop?
            
# while loops are used when there is an infinite number of guesses / combinations of characters a user has to input until they get the correct one
# for loops are used when you know an exact amount of times the user needs to guess
# also used to output solutions in a certain range
            
# 5
# enter side length of a square
# calculate surface area of a cube
# 6 * L^2
            
while True:
    s = input('Please enter the length of a side: ')
    if s.isdigit():
        s = float(s)
        a = 6 * (s ** 2)
        print(a, "is the cube's surface area")
        break
    print('Not an integer')


# 6
# write a number guessing game for numbers 1-100
# answer is a random number
# sudden death is a random number
# game ends with sudden death number

import random

a = random.randint(1, 100)
d = random.randint(1, 100)

while True:
    g = int(input('Please enter an integer: '))
    if g == a:
        print('You guessed it!!! YAY!!')
        break
    elif g == d:
        print('You died!')
        break
    print('Try again!')

# Code Examples

# output
# e

# output
# c
# a
# b
# c
# a
# b
# c
# a

# output
# That's a consonant C
# Found a vowel! A
# That's a consonant L
# Found a vowel! I 
# That's a consonant F
# Found a vowel! O
# That's a consonant R
# That's a consonant N
# Found a vowel! I
# Found a vowel! A






