'''
Your name: Ethan E. Lopez
Your teammate(s) names: George, William, Ethan B.
'''

'''
1. When should I use a while vs a for loop? Give me an example of a time I should use each
'''
# You should use a while loop for a certain condition has to be met, but you can modify your response multiple times
# setting up passwords / playing guessing games
# You should use a for loop for a parameter of conditions already met
# outputting specific values in a list

'''
2. Put the names of your teammates in a list. Then, use a for loop to say good morning to each of them.
Ex: If your teammates are named Alice and Bob, the output should be:
Good Morning Alice
Good Morning Bob
'''

names = ['George Guo', 'Ethan Bowling', 'William']

for name in names:
    print('Good Morning', name)

'''
3. Using a for loop and range(), sum all odd numbers betweeen 0 and 50,
unless the number is also divisible by 3
Ex: 1 should be added to the sum since it is odd and not divisible by 3
3 should NOT be added to the sum since it is odd but divisible by 3
'''

s = 0

for i in range(1, 50):
    if i % 2 != 0:
        if i % 3 != 0:
            s += i

print(s)

'''
4. Ask the user to enter a word. Count the number of consonants in the word with a for loop
'''
w = input('Please enter a word: ')
w = w.lower()

consonants = 0

for i in w:
    if i not in 'aeiou':
        consonants += 1

print(consonants)


'''
5. Convert this while loop into a for loop that does the same thing. Try it out with 3 different words
'''
i = 0
word = "refrigerator"
while i < len(word):
    print(word[i])
    if word[i] == "a" or word[i] == "e" or word[i] == "i" or word[i] == "o" or word[i] == "u":
        print(word[i], "is a vowel!")
        break
    else:
        i += 1

word = input('Please enter a word: ')
word = word.lower()
    
for i in word:
    print(i)
    if i in 'aeiou':
        print(i, 'is a vowel!')
        break

'''
6. Ask a user to input a positive integer. If they give you a negative number, make them try again.
Remember, the user may accidentally enter a negative number more than once.
Once you have their number, calculate the factorial (see: https://en.wikipedia.org/wiki/Factorial)
for each number from 1 to that number, and print it out (hint, use range()).
'''

while True:
    f = int(input('Please input a positive integer: '))
    if f > 0:
        break

factorial = 1
for i in range(1, f + 1):
    factorial *= i
    print('The factorial of', i, 'is', factorial)



'''
7. Use a for loop (or more than one) to check which numbers between 2 and 20 (inclusive) are prime. 
Remember prime numbers are only divisible by 1 and themselves.
Print out "[number] prime" if a number is prime and
"[number] not prime" if it is not, where [number] is replaced by the current number.
'''

for i in range(2, 21):
    if i == 2:
        print(i, 'is prime')
    for j in range(2, i):
        if i % j == 0:
            print(i, 'is not prime')
            break
        elif i - j == 1:
            print(i, 'is prime')
    
       


'''
8. A perfect number is defined as a number whos factors (other than itself) add up to itself. 
For example, 6 is a perfect number because its factors 1, 2 and 3 add up to 6.
A deficient number is one where the sum of its factors (other than itself) is LESS than itself. 
For example, 8 (1,2,4), or 9 (1,3).
An abundant number is one where the sum of its factors (other than itself) is GREATER than itself. 
For example 12 (1,2,3,4,6).
Write a python script that checks whether a number, x, is perfect, deficient, or abundant.
'''
n = int(input('Please enter number: '))

sum = 0

for i in range(1, n):
    if n % i == 0:
        sum += i

if sum == n:
    print(n, 'is a perfect number')
elif sum < n:
    print(n, 'is a deficient number')
else:
    print(n, 'is an abundant number')
