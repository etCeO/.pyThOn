# Lists and Tuples


# List syntax

l = [1, 2, 3, 'hi', ['a', 'b', 'c']]
# do NOT name your list LIST!!!!!

# Iterating through a list

names = ['Alice', 'Bob', 'Charlie']

for name in names:
    print('Good morning', name)

# Lists are mutable

l = [1, 2, 3]
l[1] = 6
print(l)

# s = 'Hello'
# s[1] = 'h'
# print(s)

# Tuple syntax

t = (1, 'giraffe', [4, 5, 6])
t2 = (4, 5, 6, 7)

for i in t2:
    print(i)

# CANT DO THAT
# t[1] = 'koala'

# List operations + & *
my_list = [1, 2, 3]
my_list2 = [4, 5, 6]

print(my_list + my_list2)
# print(my_list + 4) NO
# only add a list to another list
print(my_list + [4])
# addition is COncatenation

# * is for repetition

print(my_list * 3)
print(my_list * -1) # empty list
# NO
# print(my_list * my_list)

# in - boolean operator
# returns true if the object is an element in the list
# false otherwise

l = [1, 2, 3, [2, 3]]
print(2 in l) # returns True
print(4 in l) # returns False
print([2, 3] in l) # returns True

# List comparisons

print(['c', 'surfboard'] < ['c', 'snowboard'])

# List methods
# Modifying list methods

l = [1, 2, 3]

# .append() - appends object to end of list

s = 'Hello'
s = s.replace('H', 'j')
print(s)

# no reassignment of l needed with modifying list methods
l.append(4)
print(l)

# 3 things to know for each method
# 1) name
# 2) arguments (if any), including default arguments
# 3) what, if anything, is returned

# .pop(index) - removes and returns an object by index
# default index is the last index

l.pop(1)
print(l)

l.pop()
print(l)

# .inster(index, object) - insert object in place of index
# does not return anything

l.insert(0, 10)
print(l)

l.insert(1, 15)
print(l)

# .remove(object) - removes first instance of object
# does not return anything

states = ['California', 'Illinois', 'Vermont', 'California', 'California', 'Montana']
states.remove('California')
print(states)

# .sort() - sort the list from smallest to biggest

l.sort()
print(l)

# Non-modifying list methods

# .index(object) - grabs the first instance of that object

print(states.index('Vermont'))

# .count(object) - returns count of times object shows up

print(states.count('California'))

# functions you can use with lists

print(len(states))
print(min(l))
print(max(l))
print(sum(l))

# .sort() vs sorted()

