# While the following code technically runs,
# the code is bad - it doesn't make use of functions, it has a lot
# of repetition, and the variable names make it really hard to read
# Code like this is often called spaghetti code

# For this assignment, work with your table group to modularize this code and make it readable
# add functions where you think are necessary, limit repetition of code, etc
# Your final code should have the same output as the original.
# There is no "correct" solution for this assignment -
# I want you to use your programmer toolbox with everything you've learned this semester
# and make this code the best you can

# After you update the code, answer the questions at the bottom of the file

# Ethan E. Lopez, George Guo, William




c = "e"
e = "W"
W = "c"
print(e, end = "")
print(c, end = "")
print("l", end = "")
print(W, end = "")
print("o", end = "")
print("m", end = "")
print("e", end = "")
print()

def greeting(c, e, W):
    g = e + c + 'l' + W + 'o' + 'm' + 'e'
    return g

mystery = []

useless_variable = input("Enter your favorite meal: ")

for thing in useless_variable:
    if thing.isalpha() is False and thing != " ":
        print("That character doesn't belong in a meal....try again")
        useless_variable = input("Enter your favorite meal: ")

mystery += [useless_variable]

import math
useless_variable = input("Enter your favorite snack: ")
for thing in useless_variable:
    if thing.isalpha() is False and thing != " ":
        print("That character doesn't belong in a snack....try again")
        useless_variable = input("Enter your favorite snack: ")

mystery.append(useless_variable)


item = input("Enter your favorite dessert: ")
    
for thing in item:
    if thing.isalpha() is False and thing != " ":
        print("That character doesn't belong in a dessert....try again")
        item = input("Enter your favorite dessert: ")

mystery.append(item)


print("Here ", end = "")
print("Are ", end = "")
print("Some ", end = "")
print("Of ", end = "")
print("Your ", end = "")
print("Favorites ", end = "")
print()

print(mystery[0])
print(mystery[1])
print(mystery[2])






# AFTER YOU UPDATE THE CODE:


# 1. What were the problems with the original code?

# problems with the original code included that it made the code's output more complicated than it was supposed to be

# 2. What functions did you add to this code? Why?



# 3. What else did you do to this code to make it better? Describe in detail.


