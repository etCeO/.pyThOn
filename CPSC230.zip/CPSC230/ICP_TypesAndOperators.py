'''
Your name: Ethan E. Lopez
Your teammates names: Lloyd, Ethan, George
'''

# 1. What type is z? Write a line of code that outputs the answer

z = 10
print(type(z))

# z = 10 is an integer type.

# 2. What types that we've covered are collections? What makes something a collection?

# collections include lists, dictionaries, sets, etc.
# a collection groups multiple elements into a single unit

# 3. What is the difference between = and == in Python? When is each used?

# = assigns a variable 
# == checks for equality and comparison 
# For ex:
d = 5
5 == 5 

# 4. What type is x? Write some code that typecasts x into an int

x = 1.0
print(type(x))
x = int(x)
print(type(x))

# x is a float

'''
5. Write code that asks the user to enter 3 numbers. You'll have to ask 3 separate times.
Make sure they are a numeric type.
(Hint: what type is user input read in as? Will you have to typecast?). 
Then, use a set to print out all unique values that the user entered.

For example: If the user enters 1,1,2 you should print 1 2 back to them
'''
number_set = set()

number1 = float(input('Please enter first number: '))
number_set.add(number1)
number2 = float(input('Please enter second number: '))
number_set.add(number2)
number3 = float(input('Please enter third number: '))
number_set.add(number3)

print(number_set)

# user input is read as a string
# i'll typecast user input into a float

# 6. Print out an expression using comparison operators that returns false

print(8<4)
# 7. Print out what happens when you turn True and False into an int

a = True
b = False

print(int(a))
print(int(b))

# Explain below:
# can't put True and False into integer
# true is 1
# false is 0

# 8. Write code that checks whether or not the number 7 is even

print(7 % 2)
# if the answer is 0, it is even
# if not, it is odd


'''Challenge: 9.  Write some code that first asks the user for the hours in military time (24 hr time)
and then asks for the minutes. Use operators to convert from military time to AM/PM time

Example: If the time is 14:27 military time, the user should enter 14, and then 27
and you should output 2:27 back to them.
'''

hours = int(input('Please enter number of hours: '))
minutes = int(input('Please enter number of minutes: '))

hour = hours % 12
minute = minutes % 60
print(hour, ':', minute)
