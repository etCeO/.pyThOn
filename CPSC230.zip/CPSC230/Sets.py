# Sets

# Defining a set
# do not name your set 'set'

s = {3, 2, 1}
print(s)

t = {3, 2, 3, 1, 2}
print(t)

print(s == t)
# TRUE

# order does not matter in a set

s = {} # empty dictionary
empty_set = set() # empty set
# FINAL question!!!!!!!

# creating set from a list

my_list = [12,3,5,4,1,2,3,4,5,4,2,1,2,3]
my_set = set(my_list)

print(my_set)

# not_allowed = {[1,23], [5,4]}
# print(not_allowed)

mixed_set = {1, 4.3, 'g', (2,3)}
print(mixed_set)

# can't put mutable objects inside a set

# sets are MUTABLE!!! can't put a set in a set!!!!
# new_set = {s, v}

# but you can mix types



# set methods
# modifying set methods
# .add() and .remove()

s = {10, 9, 8, 7}
s.add(4)
s.add(4)
# will not add anything more than once
# sets only hold

print(s)

s.remove(7)
# s.remove(3)
# can't remove anything that doesn't exist

print(s)

# union (|), intersection (&), difference (-), symmetric difference (^)

odds = {1,3,5,7,9} #A
evens = {2,4,6,8,10}
pos_ints = {1,2,3,4,5,6,7,8,9,10}
primes = {2,3,5,7} #B

# union - everything from set a, set b, or both

print(odds|primes)
print(primes.union(odds))
# order does not matter

print(odds & primes)
print(primes.intersection(odds))
# order does not matter

print(odds - primes)
print(odds.difference(primes))
print(primes.difference(odds))
# ORDER DOES MATTER!!!
# first is everything in A not in B
# second is everything in B not in A

print(odds^primes)
print(primes.symmetric_difference(odds))
# order does NOT matter!!!

# in operator - boolean
# returns TRUE if element is a key in your dictionary

d = {'Jim':'John'}
print('Jim' in d)
print('John' in d)
print('John' in d.values())

'''
Write some code to ask two friends their favorite music artists,
and then print out a message telling them which artists they both said they like
'''

print('What are your favorite music artists?')
friend1 = input('(first and last names together - separate singers with spaces): ')
friend1 = friend1.split()
friend1 = set(friend1)
print("What are your friend's favorite music artists?")
friend2 = input("(first and last names together - separate singers with spaces): ")
friend2 = friend2.split()
friend2 = set(friend2)

print('You and your friend both like', friend1 & friend2)

'''
Write a function shopping_list_helper() that takes in a list of lists, recipes,
as an argument. The sublists contain ingredients for a recipe (see below). Using
sets, print out a list of unique ingredients needed by all of the recipes.
'''

my_recipes = [["apples", "sugar", "cinnamon", "nutmeg", "cloves", "butter", "flour", "vodka"],
["ground beef", "refried beans", "lettuce", "cheese", "tomato", "sour cream", "avocado"],
["lettuce", "croutons", "parmesean", "anchovies", "mayo", "mustard", "worcestershire", "lemon"],
["lemon", "sugar", "flour", "vanilla", "butter", "eggs"],
["eggs", "tomato", "bacon", "blue cheese", "lettuce", "cheese", "cucumber"]]

def shopping_list_helper(my_recipes):
    ingredients = set()
    for list in my_recipes:
        for i in list:
            ingredients.add(i)
    return ingredients

print(shopping_list_helper(my_recipes))


